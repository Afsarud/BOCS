﻿namespace BOCS.Models
{
    public class IentityUser
    {
    }
}