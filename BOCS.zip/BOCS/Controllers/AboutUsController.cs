﻿using Microsoft.AspNetCore.Mvc;

namespace BOCS.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
